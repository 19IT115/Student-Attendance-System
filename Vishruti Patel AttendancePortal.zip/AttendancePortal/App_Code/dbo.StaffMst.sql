USE [MYProject]
GO

/****** Object: Table [dbo].[StaffMst] Script Date: 25-06-2022 11:59:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StaffMst] (
    [SID]           INT            IDENTITY (1, 1) NOT NULL,
    [Name]          NVARCHAR (256) NULL,
    [StdName]       NVARCHAR (256) NULL,
    [Email]         NVARCHAR (256) NULL,
    [Mobile]        NVARCHAR (256) NULL,
    [Image]         NVARCHAR (256) NULL,
    [Qualification] NVARCHAR (256) NULL,
    [Add]           NVARCHAR (256) NULL,
    [City]          NVARCHAR (256) NULL,
    [Pincode]       NVARCHAR (256) NULL,
    [Uname]         NVARCHAR (256) NULL,
    [Pass]          NVARCHAR (256) NULL,
    [Gender]        NVARCHAR (256) NULL,
    [EDate]         DATETIME       NULL
);



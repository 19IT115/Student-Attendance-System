USE [MYProject]
GO

/****** Object: Table [dbo].[FeedBackMst] Script Date: 25-06-2022 11:59:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FeedBackMst] (
    [FID]      INT            IDENTITY (0, 1) NOT NULL,
    [Email]    NVARCHAR (250) NULL,
    [Mobile]   NVARCHAR (250) NULL,
    [Feedback] NVARCHAR (250) NULL,
    [Edate]    DATETIME       NULL
);



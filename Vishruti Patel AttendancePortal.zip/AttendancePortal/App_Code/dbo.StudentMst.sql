USE [MYProject]
GO

/****** Object: Table [dbo].[StudentMst] Script Date: 25-06-2022 11:59:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StudentMst] (
    [SID]     INT            IDENTITY (1, 1) NOT NULL,
    [RollNo]  NVARCHAR (250) NULL,
    [Name]    NVARCHAR (250) NULL,
    [StdName] NVARCHAR (250) NULL,
    [DivName] NVARCHAR (250) NULL,
    [Email]   NVARCHAR (250) NULL,
    [Mobile]  NVARCHAR (250) NULL,
    [DOB]     NVARCHAR (250) NULL,
    [Image]   NVARCHAR (250) NULL,
    [Add]     NVARCHAR (250) NULL,
    [City]    NVARCHAR (250) NULL,
    [Pincode] NVARCHAR (250) NULL,
    [Uname]   NVARCHAR (250) NULL,
    [Pass]    NVARCHAR (250) NULL,
    [EDate]   DATETIME       NULL
);



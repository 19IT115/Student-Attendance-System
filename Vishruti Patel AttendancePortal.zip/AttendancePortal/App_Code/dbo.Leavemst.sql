USE [MYProject]
GO

/****** Object: Table [dbo].[Leavemst] Script Date: 25-06-2022 11:59:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Leavemst] (
    [LID]     INT            IDENTITY (0, 1) NOT NULL,
    [rollno]  NVARCHAR (250) NULL,
    [name]    NVARCHAR (250) NULL,
    [stdname] NVARCHAR (250) NULL,
    [message] NVARCHAR (250) NULL,
    [nodays]  INT            NULL,
    [replay]  NVARCHAR (250) NULL,
    [Edate]   DATETIME       NULL
);



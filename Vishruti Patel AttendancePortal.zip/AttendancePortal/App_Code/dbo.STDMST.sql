USE [MYProject]
GO

/****** Object: Table [dbo].[STDMST] Script Date: 25-06-2022 11:59:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[STDMST] (
    [SID]     INT            IDENTITY (1, 1) NOT NULL,
    [StdName] NVARCHAR (256) NULL,
    [EDate]   DATE           NULL
);



USE [MYProject]
GO

/****** Object: Table [dbo].[Complainmst] Script Date: 25-06-2022 11:57:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Complainmst] (
    [CID]     INT            IDENTITY (0, 1) NOT NULL,
    [Rollno]  NVARCHAR (250) NULL,
    [Name]    NVARCHAR (250) NULL,
    [Subject] NVARCHAR (250) NULL,
    [Message] NVARCHAR (250) NULL,
    [Replay]  NVARCHAR (250) NULL,
    [Edate]   DATETIME       NULL
);



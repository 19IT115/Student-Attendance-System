USE [MYProject]
GO

/****** Object: Table [dbo].[Attendancemst] Script Date: 25-06-2022 11:56:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Attendancemst] (
    [AID]       INT            IDENTITY (0, 1) NOT NULL,
    [rollno]    NVARCHAR (250) NULL,
    [name]      NVARCHAR (250) NULL,
    [date]      NVARCHAR (250) NULL,
    [status]    VARCHAR (250)  NULL,
    [staffname] NVARCHAR (250) NULL,
    [edate]     DATETIME       NULL
);



USE [MYProject]
GO

/****** Object: Table [dbo].[DivMst] Script Date: 25-06-2022 11:59:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DivMst] (
    [DID]     INT           IDENTITY (0, 1) NOT NULL,
    [DIVNAME] NVARCHAR (50) NULL,
    [StdName] NVARCHAR (50) NULL,
    [Seat]    INT           NULL,
    [EDate]   DATETIME      NULL
);


